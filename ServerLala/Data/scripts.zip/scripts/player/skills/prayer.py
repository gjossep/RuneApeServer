# Bone Bury Functions
# Author: Lmctruck30
#

from server.util import ScriptManager


def itemClick_526(player, itemId, itemSlot):
	player.getPA().buryBone(5, 1600, itemId, itemSlot)

def itemClick_532(player, itemId, itemSlot):
	player.getPA().buryBone(10, 1600, itemId, itemSlot)

def itemClick_536(player, itemId, itemSlot):
	player.getPA().buryBone(15, 1600, itemId, itemSlot)

