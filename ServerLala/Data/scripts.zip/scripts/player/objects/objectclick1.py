from server.util import ScriptManager

def objectClick1_3193(player, obId, obX, obY):
	player.getPA().openUpBank()
def objectClick1_2213(player, obId, obX, obY):
	player.getPA().openUpBank()
def objectClick1_11758(player, obId, obX, obY):
	player.getPA().openUpBank()